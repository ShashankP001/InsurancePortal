import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-Register',
  templateUrl: './Register.component.html',
  styleUrls: ['./Register.component.css']
})
export class RegisterComponent implements OnInit {

  model:any = {}; 

  // @Input() valuesFromHome : any;
  @Output() registerCancel = new EventEmitter();

  constructor(private authService : AuthService) { }

  ngOnInit() {
  }

  register(){
    this.authService.register(this.model).subscribe(() => {
      console.log("registered");
    }, error => {
      console.log(error);
    });
      console.log(this.model);
  }

  cancel(){
    this.registerCancel.emit(false);
    console.log('cancelled');
  }



}
